# app/schemas/devices.py
from datetime import datetime
from typing import Optional

from pydantic import BaseModel


# ────────────────── shared base ──────────────────
class DeviceBase(BaseModel):
    account_name: str = ""
    location:     str = ""
    hostname:     str = ""


# ────────────────── CREATE payload ───────────────
class DeviceCreate(DeviceBase):
    """
    Payload accepted by POST / PUT endpoints.
    Extra fields such as ip / mac are handled on the IP-side,
    so they’re not required here.
    """
    pass


# ────────────────── READ / response ──────────────
class DeviceRead(DeviceBase):
    """
    What the API returns to the UI.  Columns that the
    DataTable looks for are included as Optional so
    their absence no longer raises ‘unknown parameter’
    warnings.
    """
    id: int

    # columns used by the JS grid (may be null / not set yet)
    device_type:          Optional[str] = None
    ip_address:           Optional[str] = None
    mac_address:          Optional[str] = None
    asset_tag:            Optional[str] = None
    updated_by_username:  Optional[str] = None

    # timestamps
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
