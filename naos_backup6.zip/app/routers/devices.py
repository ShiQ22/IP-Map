# app/routers/devices.py
from fastapi import APIRouter, Depends, HTTPException, Path
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError

from app.database import get_db
from app.models import Device, Admin, IP, OwnerType
from app.schemas.devices import DeviceCreate, DeviceRead
from app.utils.security import (
    require_admin,
    require_viewer_or_admin,
    get_current_admin,
)

router = APIRouter(prefix="/devices", tags=["devices"])


# ───────────────────────── helpers ──────────────────────────
async def _get_ip_row(db: AsyncSession, dev_id: int) -> IP | None:
    return (
        await db.execute(
            select(IP).where(
                IP.owner_type == OwnerType.device,
                IP.owner_id == dev_id,
            )
        )
    ).scalars().first()


async def _enrich(dev: Device, db: AsyncSession) -> DeviceRead:
    """Return DeviceRead with first attached-IP + updater username."""
    admin = await db.get(Admin, dev.updated_by) if dev.updated_by else None
    ip    = await _get_ip_row(db, dev.id)

    base = DeviceRead.from_orm(dev)
    return base.copy(
        update={
            "device_type":         ip.device_type if ip else None,
            "ip_address":          ip.ip_address if ip else None,
            "mac_address":         ip.mac_address if ip else None,
            "asset_tag":           ip.asset_tag   if ip else None,
            "updated_by_username": admin.username if admin else None,
        }
    )


# ────────────────────────── routes ───────────────────────────
@router.get(
    "/",
    response_model=list[DeviceRead],
    dependencies=[Depends(require_viewer_or_admin)],
)
async def list_devices(db: AsyncSession = Depends(get_db)):
    """Return every device with its first IP (if any)."""
    rows = (await db.execute(select(Device))).scalars().all()
    return [await _enrich(d, db) for d in rows]


@router.get(
    "/{dev_id}",
    response_model=DeviceRead,
    dependencies=[Depends(require_viewer_or_admin)],
)
async def get_device(
    dev_id: int = Path(...),
    db: AsyncSession = Depends(get_db),
):
    dev = await db.get(Device, dev_id)
    if not dev:
        raise HTTPException(404, "Device not found")
    return await _enrich(dev, db)


@router.post(
    "/",
    response_model=DeviceRead,
    dependencies=[Depends(require_admin)],
)
async def create_device(
    payload: DeviceCreate,
    db: AsyncSession = Depends(get_db),
    admin=Depends(get_current_admin),
):
    # 1️⃣  core record
    dev = Device(
        account_name=payload.account_name,
        location=payload.location,
        hostname=payload.hostname,
        updated_by=admin.id,
    )
    db.add(dev)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(400, "Hostname already exists")
    await db.refresh(dev)

    # 2️⃣  IP row
    ip = IP(
        owner_type=OwnerType.device,
        owner_id=dev.id,
        device_type=payload.device_type,
        ip_address=str(payload.ip_address),
        mac_address=payload.mac_address,
        asset_tag=payload.asset_tag,
        updated_by=admin.id,
    )
    db.add(ip)
    await db.commit()

    return await _enrich(dev, db)


@router.put(
    "/{dev_id}",
    response_model=DeviceRead,
    dependencies=[Depends(require_admin)],
)
async def update_device(
    dev_id: int,
    payload: DeviceCreate,
    db: AsyncSession = Depends(get_db),
    admin=Depends(get_current_admin),
):
    dev = await db.get(Device, dev_id)
    if not dev:
        raise HTTPException(404, "Device not found")

    dev.account_name = payload.account_name
    dev.location     = payload.location
    dev.hostname     = payload.hostname
    dev.updated_by   = admin.id

    ip = await _get_ip_row(db, dev_id)
    if not ip:
        ip = IP(owner_type=OwnerType.device, owner_id=dev.id)
        db.add(ip)

    ip.device_type  = payload.device_type
    ip.ip_address   = str(payload.ip_address)
    ip.mac_address  = payload.mac_address
    ip.asset_tag    = payload.asset_tag
    ip.updated_by   = admin.id

    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(400, "Hostname already exists")

    return await _enrich(dev, db)


@router.delete(
    "/{dev_id}",
    status_code=204,
    dependencies=[Depends(require_admin)],
)
async def delete_device(dev_id: int, db: AsyncSession = Depends(get_db)):
    dev = await db.get(Device, dev_id)
    if not dev:
        raise HTTPException(404, "Device not found")

    # remove child IPs first
    await db.execute(
        delete(IP).where(
            IP.owner_type == OwnerType.device,
            IP.owner_id == dev_id,
        )
    )
    await db.delete(dev)
    await db.commit()
