"""normalize device_type to lowercase and add CHECK constraint

Revision ID: 2255520df70a
Revises: 1234567890ab
Create Date: 2025-05-09 08:54:07.400129
"""
from alembic import op


# revision identifiers, used by Alembic.
revision = '2255520df70a'
down_revision = '1234567890ab'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # 1) normalize all existing values to lowercase
    op.execute(
        """
        UPDATE ips
        SET device_type = LOWER(device_type)
        WHERE device_type != LOWER(device_type)
        """
    )
    # 2) add a DB‐level CHECK to enforce only the lowercase enum values
    op.execute(
        """
        ALTER TABLE ips
        ADD CONSTRAINT chk_device_type_lower
            CHECK (device_type IN ('pc','laptop','mobile','tablet','other'))
        """
    )


def downgrade() -> None:
    # remove the CHECK constraint; data stays lowercase
    op.execute(
        "ALTER TABLE ips DROP CONSTRAINT chk_device_type_lower"
    )
