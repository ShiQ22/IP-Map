from app.database import AsyncSessionLocal
from app.models import Admin, Role
from app.utils.security import hash_password
import asyncio

async def main() -> None:
    async with AsyncSessionLocal() as session:
        admin = Admin(
            username="admin",
            password=hash_password("P@ssw0rd"),
            role=Role.admin,
        )
        session.add(admin)
        await session.commit()

if __name__ == "__main__":
    asyncio.run(main())
