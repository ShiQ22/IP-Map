# app/routers/devices.py
from fastapi import APIRouter, Depends
from app.utils.security import require_admin, require_viewer_or_admin

router = APIRouter(prefix="/devices", tags=["devices"])

@router.get("/", dependencies=[Depends(require_viewer_or_admin)])
async def list_devices():
    ...

@router.post("/", dependencies=[Depends(require_admin)])
async def create_device(...):
    ...
