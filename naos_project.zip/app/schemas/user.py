from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class DeviceBase(BaseModel):
    account_name: str
    location:     str
    hostname:     str
    ip:           str
    mac_address:  Optional[str] = None
    asset_tag:    Optional[str] = None

class DeviceCreate(DeviceBase):
    ...

class DeviceRead(DeviceBase):
    id:         int
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
