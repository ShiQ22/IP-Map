from pydantic import BaseModel
from datetime import datetime
from enum import Enum
from typing import Optional

class OwnerType(str, Enum):
    USER   = "USER"
    DEVICE = "DEVICE"
    SERVER = "SERVER"

class IPBase(BaseModel):
    ip_address: str
    mac_address: Optional[str] = None
    asset_tag:   Optional[str] = None
    owner_type:  OwnerType
    owner_id:    int

class IPCreate(IPBase):
    ...

class IPRead(IPBase):
    id:         int
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
