from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from app.config import settings
from app.models import Role
from passlib.context import CryptContext
from datetime import datetime, timedelta

# 1) define where clients get tokens
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

# 2) decode JWT and return payload
def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        data = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
    return data  # a dict like {"sub": "1", "role": "admin", ...}

# 3) viewer-or-admin guard (both roles allowed)
def require_viewer_or_admin(user: dict = Depends(get_current_user)):
    # no extra check here
    return user

# 4) admin-only guard
def require_admin(user: dict = Depends(get_current_user)):
    if user.get("role") != Role.admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN)
    return user

# Password hashing
_pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(plain: str) -> str:
    return _pwd_ctx.hash(plain)

def verify_password(plain: str, hashed: str) -> bool:
    return _pwd_ctx.verify(plain, hashed)

# JWT helpers
def create_access_token(data: dict, expires_minutes: int = 60) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=expires_minutes)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.secret_key, algorithm="HS256")

def decode_access_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.secret_key, algorithms=["HS256"])
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)