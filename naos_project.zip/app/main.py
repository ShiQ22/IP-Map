from fastapi import FastAPI
from app.config import settings
from app.routers import auth
from app.routers import user, device, server, ip
def create_app() -> FastAPI:
    app = FastAPI(title=settings.app_name)
    app.include_router(auth.router)
    return app


app.include_router(server.router)
