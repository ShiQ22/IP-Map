from datetime import datetime
from typing import Optional, Literal

from pydantic import BaseModel, Field, IPvAnyAddress


# ───────────────────── shared base ─────────────────────
class DeviceBase(BaseModel):
    account_name: str = Field("", max_length=100)
    location:     str = Field("", max_length=100)
    hostname:     str = Field("", max_length=100)


# ───────────────────── CREATE / UPDATE ─────────────────
class DeviceCreate(DeviceBase):
    """
    Payload accepted by POST & PUT.
    All fields the JS sends are declared here so payload.dict()
    contains them and the router can access `payload.device_type`, etc.
    """
    device_type: Literal[
        "pc", "laptop", "mobile", "tablet", "wifi", "other"
    ] = "other"

    ip_address:  IPvAnyAddress
    mac_address: Optional[str] = None
    asset_tag:   Optional[str] = None


# ───────────────────── READ / RESPONSE ─────────────────
class DeviceRead(DeviceBase):
    id: int

    # extra columns rendered by the grid (may be null)
    device_type:          Optional[str] = None
    ip_address:           Optional[str] = None
    mac_address:          Optional[str] = None
    asset_tag:            Optional[str] = None
    updated_by_username:  Optional[str] = None

    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
