# app/routers/ips.py

from fastapi import APIRouter, Depends, HTTPException, Path
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.database import get_db
from app.models import IP, User, OwnerType
from app.schemas.ips import IPCreate, IPRead, IPUserCreate
from app.utils.security import require_viewer_or_admin, require_admin

router = APIRouter(prefix="/api/ips", tags=["ips"])


async def enrich_row(ip: IP, db: AsyncSession) -> IPRead:
    # 1) load owner & updater
    owner = await db.get(User, ip.owner_id)
    if not owner:
        raise HTTPException(404, "Owner user not found")
    updater = await db.get(User, ip.updated_by)
    if not updater:
        raise HTTPException(404, "Updating user not found")

    # 2) lowercase any stray Enum‐backed values
    ip.device_type = ip.device_type.lower()
    ip.owner_type = ip.owner_type.lower()

    # 3) build IPRead and inject the extra fields
    base = IPRead.from_orm(ip)
    return base.copy(update={
        "owner_username":        owner.username,
        "owner_naos_id":         owner.naos_id,
        "updated_by_username":   updater.username,
    })


#
# ─── Global IP CRUD ──────────────────────────────────────────────────────────────
#

@router.get(
    "/",
    response_model=list[IPRead],
    dependencies=[Depends(require_viewer_or_admin)]
)
async def list_ips(db: AsyncSession = Depends(get_db)):
    """List all IP entries (admin or viewer)."""
    q = await db.execute(select(IP))
    rows = q.scalars().all()
    return [await enrich_row(ip, db) for ip in rows]


@router.post(
    "/",
    response_model=IPRead,
    dependencies=[Depends(require_admin)]
)
async def create_ip(
    payload: IPCreate,
    db: AsyncSession = Depends(get_db),
    admin=Depends(require_admin)
):
    """Create a standalone IP entry."""
    ip = IP(**payload.dict(), updated_by=admin.id)
    db.add(ip)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(400, "IP address already exists")
    await db.refresh(ip)
    return await enrich_row(ip, db)


@router.get(
    "/{ip_id}",
    response_model=IPRead,
    dependencies=[Depends(require_viewer_or_admin)]
)
async def read_ip(ip_id: int, db: AsyncSession = Depends(get_db)):
    """Read a single IP entry by its ID."""
    ip = await db.get(IP, ip_id)
    if not ip:
        raise HTTPException(404, "IP not found")
    return await enrich_row(ip, db)


@router.put(
    "/{ip_id}",
    response_model=IPRead,
    dependencies=[Depends(require_admin)]
)
async def update_ip(
    ip_id: int,
    payload: IPCreate,
    db: AsyncSession = Depends(get_db),
    admin=Depends(require_admin)
):
    """Update any IP entry by ID."""
    ip = await db.get(IP, ip_id)
    if not ip:
        raise HTTPException(404, "IP not found")

    for field, val in payload.dict().items():
        setattr(ip, field, val)
    ip.updated_by = admin.id

    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(400, "IP address already exists")
    await db.refresh(ip)
    return await enrich_row(ip, db)


@router.delete(
    "/{ip_id}",
    dependencies=[Depends(require_admin)]
)
async def delete_ip(ip_id: int, db: AsyncSession = Depends(get_db)):
    """Delete an IP entry by ID."""
    ip = await db.get(IP, ip_id)
    if not ip:
        raise HTTPException(404, "IP not found")
    await db.delete(ip)
    await db.commit()
    return {"detail": "IP deleted"}


#
# ─── User-Scoped IP CRUD ──────────────────────────────────────────────────────────
#

@router.get(
    "/users/{user_id}/ips",
    response_model=list[IPRead],
    dependencies=[Depends(require_viewer_or_admin)]
)
async def list_user_ips(
    user_id: int = Path(..., description="User ID"),
    db: AsyncSession = Depends(get_db),
):
    """List all IPs for a given user."""
    q = await db.execute(
        select(IP).where(
            IP.owner_type == OwnerType.user,
            IP.owner_id == user_id
        )
    )
    rows = q.scalars().all()
    return [await enrich_row(ip, db) for ip in rows]


@router.post(
    "/users/{user_id}/ips",
    response_model=IPRead,
    dependencies=[Depends(require_admin)]
)
async def create_user_ip(
    payload: IPUserCreate,
    user_id: int = Path(..., description="User ID"),
    db: AsyncSession = Depends(get_db),
    admin=Depends(require_admin)
):
    """Create a new IP entry for a specific user."""
    ip = IP(**payload.dict(),
            owner_type=OwnerType.user,
            owner_id=user_id,
            updated_by=admin.id)
    db.add(ip)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(400, "IP address already exists")
    await db.refresh(ip)
    return await enrich_row(ip, db)


@router.put(
    "/users/{user_id}/ips/{ip_id}",
    response_model=IPRead,
    dependencies=[Depends(require_admin)]
)
async def update_user_ip(
    payload: IPUserCreate,
    user_id: int = Path(..., description="User ID"),
    ip_id:   int = Path(..., description="IP entry ID"),
    db:      AsyncSession = Depends(get_db),
    admin=Depends(require_admin)
):
    """Update a specific IP entry for a user."""
    ip = await db.get(IP, ip_id)
    if (not ip or
        ip.owner_type != OwnerType.user or
        ip.owner_id != user_id):
        raise HTTPException(404, "IP entry not found for this user")

    for field, val in payload.dict().items():
        setattr(ip, field, val)
    ip.updated_by = admin.id

    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(400, "IP address already exists")
    await db.refresh(ip)
    return await enrich_row(ip, db)


@router.delete(
    "/users/{user_id}/ips/{ip_id}",
    dependencies=[Depends(require_admin)]
)
async def delete_user_ip(
    user_id: int = Path(..., description="User ID"),
    ip_id:   int = Path(..., description="IP entry ID"),
    db:      AsyncSession = Depends(get_db),
):
    """Delete a specific IP entry for a user."""
    ip = await db.get(IP, ip_id)
    if (not ip or
        ip.owner_type != OwnerType.user or
        ip.owner_id != user_id):
        raise HTTPException(404, "IP entry not found for this user")
    await db.delete(ip)
    await db.commit()
    return {"detail": "User-scoped IP deleted"}
