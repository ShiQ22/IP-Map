# app/schemas/ips.py

from datetime import datetime
from pydantic import BaseModel

class IPRead(BaseModel):
    id: int
    ip_address: str
    mac_address: str | None
    asset_tag: str | None
    department: str

    # treat these as simple strings
    device_type: str
    owner_type: str

    owner_id: int
    created_at: datetime
    updated_at: datetime

    # *** declare all three new fields ***
    owner_username: str
    owner_naos_id: str
    updated_by_username: str

    class Config:
        orm_mode = True
